const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const path = require('path');
const fs = require('fs');

const login = fs.readFileSync('login-form.html');

const app = express();
const hostname = '127.0.0.1';
const port = 5501;

// Configure middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Define route for the homepage
app.get('/', function (req, res) {
    res.sendFile('YES');
});

// Define route for sign-up page
app.get('/signup', function(req, res) {
    res.sendFile('YES');
});
app.get('/login', function (req, res) {
    res.sendFile(login);
});

// Define route for login page

// Create MySQL connection
const con = mysql.createConnection({
    host: "127.0.0.1",
    user: "root",
    password: "LtOk77%$",
    database: "nature_nectar"
});

// Connect to MySQL
con.connect(err => {
    if (err) throw err;
    console.log("Connected to MySQL!");
});
// Define route for login form submission
app.post('/', (req, res) => {
    const { Username, password } = req.body;

    // Query the database to check if the username and password match
    const query = `SELECT * FROM User WHERE Username = ? AND Password = ?`;
    const values = [Username, password];

    // Check if the user exists and password matches
    con.query(query, values, (error, results, fields) => {
        if (error) {
            console.error('Error querying database:', error);
            return res.status(500).json({ error: 'Error processing login request.' });
        }

        if (results.length > 0) {
            // User found, send "Yes" response
            res.status(200).json({ message: 'Yes' });
        } else {
            // No user found with provided credentials
            // Increase login attempts counter for the given username
            con.query(`INSERT INTO LoginAttempts (Username) VALUES (?) ON DUPLICATE KEY UPDATE Attempts = Attempts + 1`, [Username], (error, results, fields) => {
                if (error) {
                    console.error('Error updating login attempts:', error);
                    return res.status(500).json({ error: 'Error processing login request.' });
                }

                // Check if the login attempts exceed the limit
                con.query(`SELECT Attempts FROM LoginAttempts WHERE Username = ?`, [Username], (error, results, fields) => {
                    if (error) {
                        console.error('Error querying login attempts:', error);
                        return res.status(500).json({ error: 'Error processing login request.' });
                    }

                    const attempts = results[0]?.Attempts || 0;
                    if (attempts >= 3) {
                        // If attempts exceed limit, send blocking message
                        return res.status(401).json({ message: 'If you will try again to login you will be encountered by Legend Karanjeet Singh' });
                    } else {
                        // If attempts within limit, send alert message
                        return res.status(401).json({ message: 'Incorrect username or password. Attempts left: ' + (3 - attempts) });
                    }
                });
            });
        }
    });
});

// Define route for sign-up form submission
app.post('/', (req, res) => {
    // Extract sign-up data from request body
    const { username, password, role, about } = req.body;

    // Insert the user data into the database
    const query = `INSERT INTO User (Username, Password, Role, Permissions, PersonalInformation) 
                   VALUES (?, ?, ?, ?, ?)`;
    const values = [username, password, role, '', about]; // Permissions set to empty string

    con.query(query, values, (error, results, fields) => {
        if (error) {
            console.error('Error inserting user:', error);
            return res.status(500).json({ error: 'Error signing up. Please try again later.' });
        }
        // User successfully signed up
        res.status(201).json({ message: 'User signed up successfully.' });
    });

});



// Start the server
const PORT = process.env.PORT || 5501;
app.listen(PORT, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
});
