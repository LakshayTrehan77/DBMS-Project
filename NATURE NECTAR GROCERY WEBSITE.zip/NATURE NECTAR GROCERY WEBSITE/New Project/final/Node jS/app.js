// Import required modules
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const mysql = require('mysql');
// Create Express app
const app = express();
const session = require('express-session');

app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: false
}));

// Set up middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static('public'));

const con = mysql.createConnection({
    host: "127.0.0.1",
    user: "root",
    password: "karan",
    database: "nature_nectar"
});

con.connect(err => {
    if (err) throw err;
    console.log("Connected to MySQL!");
});

// Serve static files from the same directory
app.use(express.static(__dirname));

// Define routes
app.get('/form', (req, res) => {
    res.sendFile(path.join(__dirname + '/public/index.html')); // Serve the HTML form
});
// View cart
app.get('/cart/:userId', (req, res) => {
    const userId = req.params.userId;

    // Fetch items from the shoppingcart table in the database for the specified user
    const query = `SELECT * FROM shoppingcart WHERE userId = ?`;
    con.query(query, [userId], (error, results, fields) => {
        if (error) {
            console.error('Error fetching cart items:', error);
            return res.status(500).json({ error: 'Error fetching cart items. Please try again later.' });
        }
        res.status(200).json({ cartItems: results });
    });
});


app.post('/signup', (req, res) => {
    // Handle form submission here
    const { username, password, role, about } = req.body;

    // Insert the user data into the database
    const query = `INSERT INTO User (Username, Password, Role, Permissions, PersonalInformation) 
                   VALUES (?, ?, ?, ?, ?)`;
    const values = [username, password, role, '', about]; // Permissions set to empty string

    con.query(query, values, (error, results, fields) => {
        if (error) {
            console.error('Error inserting user:', error);
            return res.status(500).json({ error: 'Error signing up. Please try again later.' });
        }
        // User successfully signed up
        console.log('User signed up successfully.');
        // Show a popup indicating successful signup
        const popupHtml = `
            <script>
                alert('Signup successful! Please proceed to login.');
                window.location.href = '/login.html';
            </script>
        `;
        res.send(popupHtml);
    });
});
app.get('/analytics', (req, res) => {
    const query = 'SELECT * FROM analytics';
    con.query(query, (error, results) => {
        if (error) {
            console.error('Error fetching data from analytics table: ' + error.stack);
            res.status(500).send('Internal Server Error');
            return;
        }
        res.json(results);
    });
});
/*app.post('/login', (req, res) => {
    // Handle form submission here
    const { Username, password } = req.body;

    // Check if username and password are provided
    
    // Query the database to check if the username and password match
    const query = `SELECT * FROM User WHERE Username = ? AND Password = ?`;
    const values = [Username, password];

    // Check if the user exists and password matches
    con.query(query, values, (error, results, fields) => {
        if (error) {
            console.error('Error querying database:', error);
            return res.status(500).json({ error: 'Error processing login request.' });
        }

        if (results.length > 0) {
            // User found, send "Yes" response
            req.session.user = Username;
            console.log('User logged in:', Username);
            const redirectScript = `
                <script>
                    window.location.href = '/main.html';
                </script>
            `;
            return res.send(redirectScript);
        } else {
            // No user found with provided credentials
            // Increase login attempts counter for the given username
            con.query(`INSERT INTO LoginAttempts (Username) VALUES (?) ON DUPLICATE KEY UPDATE Attempts = Attempts + 1`, [Username], (error, results, fields) => {
                if (error) {
                    console.error('Error updating login attempts:', error);
                    return res.status(500).json({ error: 'Error processing login request.' });
                }

                // Check if the login attempts exceed the limit
                con.query(`SELECT Attempts FROM LoginAttempts WHERE Username = ?`, [Username], (error, results, fields) => {
                    if (error) {
                        console.error('Error querying login attempts:', error);
                        return res.status(500).json({ error: 'Error processing login request.' });
                    }

                    const attempts = results[0]?.Attempts || 0;
                    if (attempts >= 3) {
                        // If attempts exceed limit, block the account
                        con.query(`UPDATE User SET Blocked = 1 WHERE Username = ?`, [Username], (error, results, fields) => {
                            if (error) {
                                console.error('Error blocking account:', error);
                                return res.status(500).json({ error: 'Error processing login request.' });
                            }
                            return res.status(401).json({ message: 'Account blocked. Contact support for assistance.' });
                        });
                    } else {
                        // If attempts within limit, send alert message
                        const attemptsLeft = 3 - attempts;
                        const popupHtml = `
                            <script>
                                alert('Incorrect username or password. Attempts left: ${attemptsLeft}. Please try again.');
                                window.location.href = '/login.html';
                            </script>
                        `;
                        res.send(popupHtml);
                    }
                });
            });
        }
    });
});*/
app.post('/login', (req, res) => {
    // Handle form submission here
    const { Username, password } = req.body;

    // Check if username and password are provided

    // Query the database to check if the username and password match
    const query = `SELECT * FROM User WHERE Username = ? AND Password = ?`;
    const values = [Username, password];

    // Check if the user exists and password matches
    con.query(query, values, (error, results, fields) => {
        if (error) {
            console.error('Error querying database:', error);
            return res.status(500).json({ error: 'Error processing login request.' });
        }

        if (results.length > 0) {
            // User found, send "Yes" response
            const user = results[0]; // Assuming only one user can have the same username
            req.session.user = user.Username;

            if (user.Role === 'owner') {
                const redirectScript = `
                    <script>
                        window.location.href = '/admin.html';
                    </script>
                `;
                return res.send(redirectScript);
            } 
            else if (user.Role === 'vendor'){
                const redirectScript = `
                    <script>
                        window.location.href = '/vendor.html';
                    </script>
                `;
                return res.send(redirectScript);
            }else {
                const redirectScript = `
                    <script>
                        window.location.href = '/main.html';
                    </script>
                `;
                return res.send(redirectScript);
            }
        } else {
            // No user found with provided credentials
            // Increase login attempts counter for the given username
            con.query(`INSERT INTO LoginAttempts (Username) VALUES (?) ON DUPLICATE KEY UPDATE Attempts = Attempts + 1`, [Username], (error, results, fields) => {
                if (error) {
                    console.error('Error updating login attempts:', error);
                    return res.status(500).json({ error: 'Error processing login request.' });
                }

                // Check if the login attempts exceed the limit
                con.query(`SELECT Attempts FROM LoginAttempts WHERE Username = ?`, [Username], (error, results, fields) => {
                    if (error) {
                        console.error('Error querying login attempts:', error);
                        return res.status(500).json({ error: 'Error processing login request.' });
                    }

                    const attempts = results[0]?.Attempts || 0;
                    if (attempts >= 3) {
                        // If attempts exceed limit, block the account
                        con.query(`UPDATE User SET Blocked = 1 WHERE Username = ?`, [Username], (error, results, fields) => {
                            con.query(`UPDATE LOGINATTEMPTS SET ATTEMPTS=0 WHERE USERNAME=?`, [Username], (error, results, fields) => {
                                if (error) {
                                    console.error('Error blocking account:', error);
                                    return res.status(500).json({ error: 'Error processing login request.' });
                                }
                    
                                return res.status(401).json({ message: 'Account blocked. Contact support for assistance.' });
                            });
                        });
                    
                    
                    } else {
                        // If attempts within limit, send alert message
                        const attemptsLeft = 3 - attempts;
                        const popupHtml = `
                            <script>
                                alert('Incorrect username or password. Attempts left: ${attemptsLeft}. Please try again.');
                                window.location.href = '/login.html';
                            </script>
                        `;
                        res.send(popupHtml);
                    }
                });
            });
        }
    });
});

app.delete('/delete/:productId', (req, res) => {
    const productId = req.params.productId;

    // Run query to delete item from the cart with the specified product ID
    const deleteQuery = 'DELETE FROM shoppingcart WHERE ProductID = ?';

    con.query(deleteQuery, [productId], (error, results) => {
        if (error) {
            console.error('Error deleting item from cart:', error);
            res.status(500).json({ error: 'Internal server error' });
        } else {
            res.status(200).json({ message: 'Item removed from cart successfully' });
        }
    });
});

app.delete('/deleteS/:userID', (req, res) => {
    const userID = req.params.userID; // Get userID from request parameters
    
    // Fetch the total price and generate an order ID
    const calculateTotalQuery = 'SELECT SUM(TotalPrice) AS totalPrice FROM shoppingcart';
    con.query(calculateTotalQuery, (error, results) => {
        if (error) {
            console.error('Error calculating total price:', error);
            res.status(500).json({ error: 'Internal server error' });
            return; // Exit the function early if there's an error
        }

        const totalPrice = results[0].totalPrice || 0; // If no items in the cart, set total price to 0
        const currentTime = new Date().toISOString().slice(0, 19).replace('T', ' '); // Current time in MySQL format
        const orderID = generateRandomInteger(); // Generate a random integer order ID

        // Send the total price as a response along with the message
        const message = 'Your total Price is ' + totalPrice;
        res.status(200).json({ message: message, totalPrice: totalPrice });

        // Insert data into the orders table
        const insertOrderQuery = 'INSERT INTO orders (OrderID, UserID, TotalAmount, OrderDate) VALUES (?, ?, ?, ?)';
        con.query(insertOrderQuery, [orderID, userID, totalPrice, currentTime], (error, results) => {
            if (error) {
                console.error('Error inserting order:', error);
                res.status(500).json({ error: 'Internal server error' });
                return; // Exit the function early if there's an error
            }

            // Fetch productID and quantity from shoppingcart
            const selectProductsQuery = 'SELECT ProductID, Quantity FROM shoppingcart';
            con.query(selectProductsQuery, (error, cartItems) => {
                if (error) {
                    console.error('Error selecting products from cart:', error);
                    res.status(500).json({ error: 'Internal server error' });
                    return; // Exit the function early if there's an error
                }

                // Run query to insert data into the sales table for each item in the cart
                cartItems.forEach(item => {
                    const { ProductID, Quantity } = item;
                    const insertSalesQuery = 'INSERT INTO sales (ProductID, QuantitySold, SaleDate) VALUES (?, ?, ?)';
                    con.query(insertSalesQuery, [ProductID, Quantity, currentTime], (error, results) => {
                        if (error) {
                            console.error('Error inserting sales data:', error);
                            res.status(500).json({ error: 'Internal server error' });
                            return; // Exit the function early if there's an error
                        }
                    });
                    
                    // Update inventory quantities based on sales
                   /* const updateInventoryQuery = 'UPDATE inventory SET Quantity = Quantity - ? WHERE ProductID = ?';
                    con.query(updateInventoryQuery, [Quantity, ProductID], (inventoryError, inventoryResults) => {
                        if (inventoryError) {
                            console.error('Error updating inventory quantity:', inventoryError);
                            res.status(500).json({ error: 'Internal server error' });
                            return; // Exit the function early if there's an error
                        }
                    });*/
                });

                // Run query to delete items from the shopping cart
                const deleteQuery = 'DELETE FROM shoppingcart';
                con.query(deleteQuery, (deleteError, deleteResults) => {
                    if (deleteError) {
                        console.error('Error deleting items from cart:', deleteError);
                        res.status(500).json({ error: 'Internal server error' });
                        return; // Exit the function early if there's an error
                    }

                    // Send a response indicating success along with total price and order ID
                    res.status(200).json({ message: 'Items removed from cart successfully', totalPrice: totalPrice, orderID: orderID });
                });
            });
        });
    });
});



function generateRandomInteger() {
    // Change this to set the range of random integers for orderID
    const min = 1000;
    const max = 9999;
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Define the route to handle GET requests for total price
app.get('/getTotalPrice/:userID', (req, res) => {
    const userID = req.params.userID;

    // Run query to get the total price for the specified user ID
    const getTotalPriceQuery = 'SELECT SUM(TotalPrice) AS totalPrice FROM shoppingcart WHERE UserID = ?';
    con.query(getTotalPriceQuery, [userID], (error, results) => {
        if (error) {
            console.error('Error getting total price:', error);
            res.status(500).json({ error: 'Internal server error' });
            return;
        }

        const totalPrice = results[0].totalPrice || 0; // If no items in the cart, set total price to 0
        res.status(200).json({ totalPrice: totalPrice });
    });
});


// Add item to cart
app.post('/addToCart', (req, res) => {
    const { CartID, UserID, ProductID, Quantity, TotalPrice } = req.body;
    const Status = 'Active'; // Set the status to "Active"
    const query = `INSERT INTO shoppingcart (CartID, UserID, ProductID, Quantity, TotalPrice, Status) VALUES (?, ?, ?, ?, ?, ?)`;
    con.query(query, [CartID, UserID, ProductID, Quantity, TotalPrice, Status], (error, results, fields) => {
        if (error) {
            console.error('Error adding to cart:', error);
            return res.status(500).json({ error: 'Error adding to cart. Please try again later.' });
        }
        res.status(200).json({ message: 'Product added to cart successfully.' });
    });
});


// Add a new route to fetch the username
app.get('/auth/username', (req, res) => {
    const username = req.session.user;
    if (username) {
        res.json({ username });
    } else {
        res.status(401).json({ error: 'User not authenticated' });
    }
});
// Fetch inventory data
app.get('/inventory', (req, res) => {
    // Fetch all data from the inventory table
    const query = `SELECT * FROM inventory`;
    con.query(query, (error, results, fields) => {
        if (error) {
            console.error('Error fetching inventory data:', error);
            return res.status(500).json({ error: 'Error fetching inventory data. Please try again later.' });
        }
        res.status(200).json({ inventory: results });
    });
});
app.get('/vendorapplications', (req, res) => {
    // Fetch all data from the inventory table
    const query = `SELECT * FROM VendorApplication`;
    con.query(query, (error, results, fields) => {
        if (error) {
            console.error('Error fetching inventory data:', error);
            return res.status(500).json({ error: 'Error fetching inventory data. Please try again later.' });
        }
        res.status(200).json({ inventory: results });
    });
});
app.get('/vendorapplications/:applicationId', (req, res) => {
    const applicationId = req.params.applicationId;
    // Query the database to fetch data for the specified application ID
    const query = `SELECT * FROM VendorApplication WHERE ApplicationID = ?`;
    con.query(query, [applicationId], (error, results) => {
        if (error) {
            console.error('Error fetching application data:', error);
            return res.status(500).json({ error: 'Error fetching application data. Please try again later.' });
        }
        if (results.length === 0) {
            return res.status(404).json({ error: 'Application not found.' });
        }
        res.status(200).json({ application: results[0] });
    });
});


// Assuming you have already set up your Express app and configured your database connection (con)

// Endpoint to handle updating status
app.post('/updatestatus/:applicationId', (req, res) => {
    const applicationId = req.params.applicationId;
    const newStatus = req.body.status;

    // Update the status in the database
    const query = `UPDATE VendorApplication SET Status = ? WHERE ApplicationID = ?`;
    con.query(query, [newStatus, applicationId], (error, results) => {
        if (error) {
            console.error('Error updating status:', error);
            return res.status(500).json({ success: false, error: 'Error updating status.' });
        }
        res.json({ success: true });
    });
});
app.post('/insertvendor', (req, res) => {
    const applicationId = req.body.applicationId;
    const vendorName = req.body.vendorName;
    
    // Fetch current date
    const currentDate = new Date().toISOString().slice(0, 10); // Format: YYYY-MM-DD

    // Insert vendor data into the database
    const query = `INSERT INTO Vendor (VendorName, RegistrationDate, ApplicationID) VALUES (?, ?, ?)`;
    con.query(query, [vendorName, currentDate, applicationId], (error, results) => {
        if (error) {
            console.error('Error inserting vendor:', error);
            return res.status(500).json({ success: false, error: 'Error inserting vendor.' });
        }
        res.json({ success: true });
    });
});




app.post('/inventorys', (req, res) => {
    const { ProductID, Quantity, LowInventoryAlert } = req.body;
    const query = `INSERT INTO inventory (ProductID, Quantity, LowInventoryAlert) VALUES (?, ?, ?)`;
    con.query(query, [ProductID, Quantity, LowInventoryAlert], (error, results, fields) => {
        if (error) {
            console.error('Error inserting inventory data:', error);
            return res.status(500).json({ error: 'Error inserting inventory data. Please try again later.' });
        }
        res.status(200).json({ message: 'Inventory data inserted successfully.' });
    });
});
// Update inventory entry by ID (with row-level locking)
app.put('/inventory/:id', (req, res) => {
    const ProductID = req.params.id;
    const { Quantity, LowInventoryAlert } = req.body;

    // Begin transaction
    con.beginTransaction((beginTransactionErr) => {
        if (beginTransactionErr) {
            return res.status(500).json({ error: 'Error beginning transaction. Please try again later.' });
        }

        // Lock the row for update
        const lockQuery = 'SELECT * FROM inventory WHERE ProductID = ? FOR UPDATE';
        con.query(lockQuery, [ProductID], (lockError, lockResults) => {
            if (lockError) {
                return con.rollback(() => {
                    res.status(500).json({ error: 'Error locking inventory entry. Please try again later.' });
                });
            }

            // Proceed with update
            const updateQuery = 'UPDATE inventory SET Quantity = ?, LowInventoryAlert = ? WHERE ProductID = ?';
            con.query(updateQuery, [Quantity, LowInventoryAlert, ProductID], (updateError, updateResults, updateFields) => {
                if (updateError) {
                    return con.rollback(() => {
                        res.status(500).json({ error: 'Error updating inventory data. Please try again later.' });
                    });
                }

                // Commit the transaction
                con.commit((commitError) => {
                    if (commitError) {
                        return con.rollback(() => {
                            res.status(500).json({ error: 'Error committing transaction. Please try again later.' });
                        });
                    }
                    res.status(200).json({ message: 'Inventory data updated successfully.' });
                });
            });
        });
    });
});

// Delete inventory entry by ID (with row-level locking)
app.delete('/inventory/:id', (req, res) => {
    const ProductID = req.params.id;

    // Begin transaction
    con.beginTransaction((beginTransactionErr) => {
        if (beginTransactionErr) {
            return res.status(500).json({ error: 'Error beginning transaction. Please try again later.' });
        }

        // Lock the row for delete
        const lockQuery = 'SELECT * FROM inventory WHERE ProductID = ? FOR UPDATE';
        con.query(lockQuery, [ProductID], (lockError, lockResults) => {
            if (lockError) {
                return con.rollback(() => {
                    res.status(500).json({ error: 'Error locking inventory entry. Please try again later.' });
                });
            }

            // Proceed with deletion
            const deleteQuery = 'DELETE FROM inventory WHERE ProductID = ?';
            con.query(deleteQuery, [ProductID], (deleteError, deleteResults, deleteFields) => {
                if (deleteError) {
                    return con.rollback(() => {
                        res.status(500).json({ error: 'Error deleting inventory data. Please try again later.' });
                    });
                }

                // Commit the transaction
                con.commit((commitError) => {
                    if (commitError) {
                        return con.rollback(() => {
                            res.status(500).json({ error: 'Error committing transaction. Please try again later.' });
                        });
                    }
                    res.status(200).json({ message: 'Inventory data deleted successfully.' });
                });
            });
        });
    });
});

// Create an order
// Create an order
app.post('/orders', (req, res) => {
    const { customerId, items } = req.body;

    // Calculate total amount for the order
    let totalAmount = 0;
    for (const item of items) {
        totalAmount += item.price * item.quantity;
    }

    // Start a database transaction
    con.beginTransaction(error => {
        if (error) {
            console.error('Error starting transaction:', error);
            return res.status(500).json({ error: 'Error processing order. Please try again later.' });
        }

        // Insert the order into the database
        const orderQuery = `INSERT INTO Orders (CustomerId, TotalAmount) VALUES (?, ?)`;
        con.query(orderQuery, [customerId, totalAmount], (orderError, orderResult) => {
            if (orderError) {
                console.error('Error inserting order:', orderError);
                con.rollback(() => {
                    console.error('Transaction rolled back');
                    return res.status(500).json({ error: 'Error processing order. Please try again later.' });
                });
            }

            // Insert order items into the database
            const orderItemsQuery = `INSERT INTO OrderItems (OrderId, ProductId, Quantity, Price) VALUES (?, ?, ?, ?)`;
            for (const item of items) {
                con.query(orderItemsQuery, [orderResult.insertId, item.productId, item.quantity, item.price], (itemError, itemResult) => {
                    if (itemError) {
                        console.error('Error inserting order item:', itemError);
                        con.rollback(() => {
                            console.error('Transaction rolled back');
                            return res.status(500).json({ error: 'Error processing order. Please try again later.' });
                        });
                    }
                });
            }

            // Commit the transaction
            con.commit(commitError => {
                if (commitError) {
                    console.error('Error committing transaction:', commitError);
                    con.rollback(() => {
                        console.error('Transaction rolled back');
                        return res.status(500).json({ error: 'Error processing order. Please try again later.' });
                    });
                }
                console.log('Transaction committed');
                res.status(201).json({ message: 'Order created successfully' });
            });
        });
    });
});
// Fetch products from the database
// Fetch details of a single product
// Fetch all products
// Fetch products from the database

//const app = express();
//const path = require('path'); // Import the path module

// Serve static files from the specified directory
// Serve static files from the specified directory
app.use('/images', express.static(path.join(__dirname, 'public', 'images')));


app.get('/products', (req, res) => {
    const query = `SELECT * FROM product`;
    con.query(query, (error, results, fields) => {
        if (error) {
            console.error('Error fetching products:', error);
            return res.status(500).json({ error: 'Error fetching products. Please try again later.' });
        }
        
        // Modify each product to include the complete image URL
        const productsWithImageURLs = results.map(product => {
            const imageUrl = `${product.image_url}`;
            console.log('Image URL for product', product.id, ':', imageUrl);
            return {
                ...product,
                image_url: imageUrl
            };
        });

        res.status(200).json({ products: productsWithImageURLs });
    });
});

app.get('/productsS/:userID', (req, res) => {
    const userID = req.params.userID;
    const query = `SELECT * FROM SHOPPINGCART WHERE userID = ?`;
    con.query(query, [userID], (error, results, fields) => {
        if (error) {
            console.error('Error fetching products:', error);
            return res.status(500).json({ error: 'Error fetching products. Please try again later.' });
        }

        // List the data from the shopping cart
        res.status(200).json({ shopping_cart_items: results });
    });
});

process.on('exit', () => {
    con.query("DELETE FROM SHOPPINGCART WHERE UserID != 0", (error, results, fields) => {
        if (error) {
            console.error('Error deleting shopping cart items:', error);
        } else {
            console.log('All shopping cart items deleted successfully.');
        }
        // Close the database connection
        con.end();
    });
});







// Create an order
// Create an order
app.post('/checkout', (req, res) => {
    const { OrderID, UserID, TotalAmount, Items } = req.body;

    // Get the current date and time
    const currentDate = new Date();

    // Format the date to 'YYYY-MM-DD HH:MM:SS'
    const formattedDate = currentDate.toISOString().slice(0, 19).replace('T', ' ');

    // Insert the order data into the orders table
    const query = `INSERT INTO orders (OrderID, UserID, TotalAmount, OrderDate) VALUES (?, ?, ?, ?)`;
    const values = [OrderID, UserID, TotalAmount, formattedDate]; // Include TotalAmount value here

    // Execute the query
    con.query(query, values, (error, results, fields) => {
        if (error) {
            console.error('Error inserting data into orders table:', error);
            return res.status(500).json({ error: 'Error processing checkout. Please try again later.' });
        }

      

        // Respond with success message
        res.status(200).json({ message: 'Checkout successful. Order placed successfully.' });
    });
});



// Route to handle adding products to the shopping cart
app.post('/addToCart', (req, res) => {
    const { CartID, UserID, ProductID, Quantity, TotalPrice } = req.body; // Corrected destructuring
    const Status = 'Active'; // Set the status to "Active"
    const query = `INSERT INTO shoppingcart (CartID, UserID, ProductID, Quantity, TotalPrice, Status) VALUES (?, ?, ?, ?, ?, ?)`; // Corrected query
    con.query(query, [CartID, UserID, ProductID, Quantity, TotalPrice, Status], (error, results, fields) => {
        if (error) {
            console.error('Error adding to cart:', error);
            return res.status(500).json({ error: 'Error adding to cart. Please try again later.' });
        }
        res.status(200).json({ message: 'Product added to cart successfully.' });
        
    });
});







app.post('/services', (req, res) => {
    const query = 'SELECT * FROM product';
    connection.query(query, (error, results) => {
        if (error) {
            console.error('Error fetching data:', error);
            res.status(500).json({ error: 'Internal Server Error' });
            return;
        }
        res.json(results);
    });
});
app.post('/feedback', (req, res) => {
    const { rating, comment, userID, productID } = req.body;

    // Insert the feedback data into the database
    const query = `INSERT INTO Feedback (UserID, ProductID, Rating, Comment) 
                   VALUES (?, ?, ?, ?)`;
    const values = [userID, productID, rating, comment];

    con.query(query, values, (error, results, fields) => {
        if (error) {
            console.error('Error inserting feedback:', error);
            return res.status(500).json({ error: 'Error submitting feedback. Please try again later.' });
        }
        // Feedback successfully submitted
        res.redirect('/thankyou.html');
    });
});
app.post('/feedbackS', (req, res) => {
    const {DocumentID } = req.body;
    
    // Insert vendor application data into the database
    const vendorQuery = `INSERT INTO VendorApplication ( Status,Documents) 
                         VALUES ("PENDING",?)`;
    //const randomVendorID =  Math.floor(Math.random() * (1000 - 11 + 1)) + 11; // Random integer between 1 and 1000
    const vendorValues = [ DocumentID];

    con.query(vendorQuery, vendorValues, (vendorError, vendorResults, vendorFields) => {
        if (vendorError) {
            console.error('Error inserting vendor application:', vendorError);
            return res.status(500).json({ error: 'Error submitting vendor application. Please try again later.' });
        }
        // Vendor application successfully submitted
        res.redirect('/thankyou.html');
    });
});
// Update status of an application with transaction
app.post('/updatestatus/:applicationId', (req, res) => {
    const applicationId = req.params.applicationId;
    const newStatus = req.body.status;

    // Begin transaction
    con.beginTransaction((beginTransactionErr) => {
        if (beginTransactionErr) {
            console.error('Error beginning transaction:', beginTransactionErr);
            return res.status(500).json({ success: false, error: 'Error beginning transaction.' });
        }

        // Update the status in the database
        const updateQuery = 'UPDATE VendorApplication SET Status = ? WHERE ApplicationID = ?';
        con.query(updateQuery, [newStatus, applicationId], (updateError, updateResults) => {
            if (updateError) {
                console.error('Error updating status:', updateError);
                return con.rollback(() => {
                    res.status(500).json({ success: false, error: 'Error updating status.' });
                });
            }

            // Commit the transaction
            con.commit((commitError) => {
                if (commitError) {
                    console.error('Error committing transaction:', commitError);
                    return con.rollback(() => {
                        res.status(500).json({ success: false, error: 'Error committing transaction.' });
                    });
                }
                res.json({ success: true });
            });
        });
    });
});

app.get('/procurements', (req, res) => {
    const query = 'SELECT * FROM procurement';
    con.query(query, (err, result) => {
        if (err) {
            console.error('Error fetching procurement data:', err);
            res.status(500).json({ error: 'Failed to fetch procurement data' });
            return;
        }
        res.json({ procurement: result });
    });
});

// Endpoint to add a procurement
app.post('/addProcurement', (req, res) => {
    const { ProcurementID, VendorID, MSP, ApprovalStatus, Name } = req.body;
    const GovernmentOfficialID = 1; // Default government official ID

    const insertQuery = 'INSERT INTO procurement (ProcurementID, VendorID, GovernmentOfficialID, MSP, ApprovalStatus, Name) VALUES (?, ?, ?, ?, ?, ?)';

    // Execute the insert query
    con.query(insertQuery, [ProcurementID, VendorID, GovernmentOfficialID, MSP, ApprovalStatus, Name], (err, result) => {
        if (err) {
            console.error('Error adding procurement:', err);
            res.status(500).json({ error: 'Failed to add procurement' });
            return;
        }
        console.log('Procurement added successfully:', result);
        res.json({ message: 'Procurement added successfully', procurement: { ProcurementID, VendorID, GovernmentOfficialID, MSP, ApprovalStatus, Name } });
    });
});
app.post('/addProduct', (req, res) => {
    const { ProductID, Name, Description, Price, image_url } = req.body;
    const MSP = 0; // Set MSP to zero

    const insertQuery = 'INSERT INTO product (ProductID, Name, Description, Price,  MSP, image_url) VALUES (?, ?, ?, ?, ?, ?)';
    const deleteQuery = 'DELETE FROM PRODUCT WHERE PRICE < ?';

    // Execute the insert query
    con.query(insertQuery, [ProductID, Name, Description, Price, MSP, image_url], (err, result) => {
        if (err) {
            console.error('Error adding product:', err);
            res.status(500).json({ error: 'Failed to add product' });
            return;
        }
        console.log('Product added successfully:', result);
        // Execute the delete query after successful insertion
        con.query(deleteQuery, [MSP], (err, deleteResult) => {
            if (err) {
                console.error('Error deleting products:', err);
                // You might choose to handle this error differently, depending on your requirements
            } else {
                console.log('Products deleted successfully:', deleteResult);
            }
        });
        res.json({ message: 'Product added successfully' });
    });
});
/// Add analytics entry
app.post('/analytics', (req, res) => {
    const { ReportType, ReportData } = req.body;
    const currentDate = new Date();
    const GenerationDate = currentDate.toISOString().slice(0, 19).replace('T', ' ');// Automatically set the generation date
    
    const query = `INSERT INTO analytics (ReportType, ReportData, GenerationDate) VALUES (?, ?, ?)`;
    con.query(query, [ReportType, ReportData, GenerationDate], (error, results, fields) => {
        if (error) {
            console.error('Error adding analytics entry:', error);
            return res.status(500).json({ error: 'Error adding analytics entry. Please try again later.' });
        }
        res.status(200).json({ message: 'Analytics entry added successfully.' });
    });
});

// Queue to store pending operations
const operationQueue = [];

// Function to process the next operation in the queue
const processNextOperation = () => {
    if (operationQueue.length > 0) {
        const operation = operationQueue.shift(); // Get the next operation from the queue
        operation(); // Execute the operation
    }
};
// Update analytics entry by ID (with row-level locking)
app.put('/analytics/:id', (req, res) => {
    const id = req.params.id;
    const { ReportType, ReportData } = req.body;
    
    // Begin transaction
    con.beginTransaction((beginTransactionErr) => {
        if (beginTransactionErr) {
            return res.status(500).json({ error: 'Error beginning transaction. Please try again later.' });
        }
        
        // Lock the row for update
        const lockQuery = 'SELECT * FROM analytics WHERE AnalyticsID = ? FOR UPDATE';
        con.query(lockQuery, [id], (lockError, lockResults) => {
            if (lockError) {
                return con.rollback(() => {
                    res.status(500).json({ error: 'Error locking analytics entry. Please try again later.' });
                });
            }
            
            // Check if ID exists before updating
            const checkQuery = 'SELECT * FROM analytics WHERE AnalyticsID = ?';
            con.query(checkQuery, [id], (checkError, checkResults, checkFields) => {
                if (checkError) {
                    return con.rollback(() => {
                        res.status(500).json({ error: 'Error checking analytics entry. Please try again later.' });
                    });
                }
                if (checkResults.length === 0) {
                    return con.rollback(() => {
                        res.status(404).json({ error: 'The corresponding analytics entry does not exist.' });
                    });
                }
                
                // Proceed with update if ID exists
                const updateQuery = 'UPDATE analytics SET ReportType = ?, ReportData = ? WHERE AnalyticsID = ?';
                con.query(updateQuery, [ReportType, ReportData, id], (updateError, updateResults, updateFields) => {
                    if (updateError) {
                        return con.rollback(() => {
                            res.status(500).json({ error: 'Error updating analytics entry. Please try again later.' });
                        });
                    }
                    
                    // Commit the transaction
                    con.commit((commitError) => {
                        if (commitError) {
                            return con.rollback(() => {
                                res.status(500).json({ error: 'Error committing transaction. Please try again later.' });
                            });
                        }
                        return res.status(200).json({ message: 'Analytics entry updated successfully.' });
                    });
                });
            });
        });
    });
});

// Delete analytics entry by ID (with row-level locking)
app.delete('/analytics/:id', (req, res) => {
    const id = req.params.id;
    
    // Begin transaction
    con.beginTransaction((beginTransactionErr) => {
        if (beginTransactionErr) {
            return res.status(500).json({ error: 'Error beginning transaction. Please try again later.' });
        }
        
        // Lock the row for update
        const lockQuery = 'SELECT * FROM analytics WHERE AnalyticsID = ? FOR UPDATE';
        con.query(lockQuery, [id], (lockError, lockResults) => {
            if (lockError) {
                return con.rollback(() => {
                    res.status(500).json({ error: 'Error locking analytics entry. Please try again later.' });
                });
            }
            
            // Check if ID exists before deleting
            const checkQuery = 'SELECT * FROM analytics WHERE AnalyticsID = ?';
            con.query(checkQuery, [id], (checkError, checkResults, checkFields) => {
                if (checkError) {
                    return con.rollback(() => {
                        res.status(500).json({ error: 'Error checking analytics entry. Please try again later.' });
                    });
                }
                if (checkResults.length === 0) {
                    return con.rollback(() => {
                        res.status(404).json({ error: 'The corresponding analytics entry does not exist.' });
                    });
                }
                
                // Proceed with deletion if ID exists
                const deleteQuery = 'DELETE FROM analytics WHERE AnalyticsID = ?';
                con.query(deleteQuery, [id], (deleteError, deleteResults, deleteFields) => {
                    if (deleteError) {
                        return con.rollback(() => {
                            res.status(500).json({ error: 'Error deleting analytics entry. Please try again later.' });
                        });
                    }
                    
                    // Commit the transaction
                    con.commit((commitError) => {
                        if (commitError) {
                            return con.rollback(() => {
                                res.status(500).json({ error: 'Error committing transaction. Please try again later.' });
                            });
                        }
                        return res.status(200).json({ message: 'Analytics entry deleted successfully.' });
                    });
                });
            });
        });
    });
});


app.get('/thankyou.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'thankyou.html')); // Serve the 'thank you' page
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
