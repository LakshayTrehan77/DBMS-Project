// Import required modules
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const mysql = require('mysql');
// Create Express app
const app = express();

// Set up middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static('public'));

const con = mysql.createConnection({
    host: "127.0.0.1",
    user: "root",
    password: "LtOk77%$",
    database: "nature_nectar"
});


con.connect(err => {
    if (err) throw err;
    console.log("Connected to MySQL!");
    
});
// Serve static files from the same directory
app.use(express.static(__dirname));

// Define routes
app.get('/form', (req, res) => {
    res.sendFile(path.join(__dirname + '/public/index.html')); // Serve the HTML form
});

app.post('/formPost', (req, res) => {
    // Handle form submission here
    console.log(req.body);
    // You can process the form data here (e.g., save to a database)

    // Redirect to the 'thank you' page
    res.redirect('/thankyou.html');
});
app.post('/signup', (req, res) => {
    // Handle form submission here
    const { username, password, role, about } = req.body;

    // Insert the user data into the database
    const query = `INSERT INTO User (Username, Password, Role, Permissions, PersonalInformation) 
                   VALUES (?, ?, ?, ?, ?)`;
    const values = [username, password, role, '', about]; // Permissions set to empty string

    con.query(query, values, (error, results, fields) => {
        if (error) {
            console.error('Error inserting user:', error);
            return res.status(500).json({ error: 'Error signing up. Please try again later.' });
        }
        // User successfully signed up
        res.status(201).json({ message: 'User signed up successfully.' });
    });
});

app.post('/login', (req, res) => {
    // Handle form submission here
    const { Username, password } = req.body;

    // Query the database to check if the username and password match
    const query = `SELECT * FROM User WHERE Username = ? AND Password = ?`;
    const values = [Username, password];

    // Check if the user exists and password matches
    con.query(query, values, (error, results, fields) => {
        if (error) {
            console.error('Error querying database:', error);
            return res.status(500).json({ error: 'Error processing login request.' });
        }

        if (results.length > 0) {
            // User found, send "Yes" response
            res.status(200).json({ message: 'Yes' });
        } else {
            // No user found with provided credentials
            // Increase login attempts counter for the given username
            con.query(`INSERT INTO LoginAttempts (Username) VALUES (?) ON DUPLICATE KEY UPDATE Attempts = Attempts + 1`, [Username], (error, results, fields) => {
                if (error) {
                    console.error('Error updating login attempts:', error);
                    return res.status(500).json({ error: 'Error processing login request.' });
                }

                // Check if the login attempts exceed the limit
                con.query(`SELECT Attempts FROM LoginAttempts WHERE Username = ?`, [Username], (error, results, fields) => {
                    if (error) {
                        console.error('Error querying login attempts:', error);
                        return res.status(500).json({ error: 'Error processing login request.' });
                    }

                    const attempts = results[0]?.Attempts || 0;
                    if (attempts >= 3) {
                        // If attempts exceed limit, send blocking message
                        return res.status(401).json({ message: 'If you will try again to login you will be encountered by Legend Karanjeet Singh' });
                    } else {
                        // If attempts within limit, send alert message
                        return res.status(401).json({ message: 'Incorrect username or password. Attempts left: ' + (3 - attempts) });
                    }
                });
            });
        }
    });
});

app.get('/thankyou.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'thankyou.html')); // Serve the 'thank you' page
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
